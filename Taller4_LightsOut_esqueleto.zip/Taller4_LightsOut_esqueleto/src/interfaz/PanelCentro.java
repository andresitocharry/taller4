package interfaz;

import javax.imageio.ImageIO;
import javax.swing.*;

import uniandes.dpoo.taller4.modelo.Tablero;

import java.awt.*;
import java.io.File;

public class PanelCentro extends JPanel {
    private Tablero tableroJuego;
    private Image image;
    private int tamanoinicial =5;

    public PanelCentro() {
        tableroJuego = crearTablero(tamanoinicial);

        try {
            // Carga la imagen desde la ruta especificada
            image = ImageIO.read(new File("data/luz.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        
        
       
        	
    }

    public static Tablero crearTablero(int tamanio) {
        Tablero nuevotab = new Tablero(tamanio);
        return nuevotab;
    }
}
