package interfaz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import interfaz.PanelCentro;

public class PanelSuperior extends JPanel {
    private JComboBox<String> gridSizeComboBox;
    private JLabel dificultadLabel;
    private JRadioButton facilRadioButton;
    private JRadioButton medioRadioButton;
    private JRadioButton dificilRadioButton;
    
    public PanelSuperior() {
        gridSizeComboBox = new JComboBox<>(new String[] { "5x5", "4x4", "6x6" });
        add(new JLabel("Tama�o de la Cuadr�cula:"));
        add(gridSizeComboBox);
        
        dificultadLabel = new JLabel("Dificultad:");
        add(dificultadLabel);
        
        ButtonGroup dificultadGroup = new ButtonGroup();
        
        facilRadioButton = new JRadioButton("F�cil");
        medioRadioButton = new JRadioButton("Medio");
        dificilRadioButton = new JRadioButton("Dif�cil");
        
        dificultadGroup.add(facilRadioButton);
        dificultadGroup.add(medioRadioButton);
        dificultadGroup.add(dificilRadioButton);
        
        add(facilRadioButton);
        add(medioRadioButton);
        add(dificilRadioButton);
        
        gridSizeComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	String selectedSize = (String) gridSizeComboBox.getSelectedItem();
                int tamano = 0;

                // Determina el tama�o seleccionado
                if (selectedSize.equals("5x5")) {
                    tamano = 5;
                } else if (selectedSize.equals("4x4")) {
                    tamano = 4;
                } else if (selectedSize.equals("6x6")) {
                    tamano = 6;
                }
                
                add(new JLabel(String.valueOf(tamano)));
                
                if(tamano > 0) {
                	PanelCentro.crearTablero(tamano);
                }

                
            }
        });
    }
}