package interfaz;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;


import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import javax.imageio.*;

import interfaz.PanelSuperior;
import interfaz.PanelInferior;
import interfaz.PanelDerecho;
import interfaz.PanelCentro;



public class JFrame_principal extends JFrame {
	
	private PanelSuperior panelsup;
	private PanelInferior panelinf;
	private PanelDerecho paneliz;
	private PanelCentro panelcen;

	public JFrame_principal() {

		this.setTitle("LightsOut");
		this.setBounds(0,0,500,400);

		panelsup = new  PanelSuperior();
		panelinf = new PanelInferior();
	    paneliz = new PanelDerecho();
		panelcen = new PanelCentro();
		this.setLayout(new BorderLayout());
        this.add(panelsup,BorderLayout.NORTH);
        this.add(panelinf,BorderLayout.SOUTH);
        this.add(paneliz,BorderLayout.EAST);
        this.add(panelcen,BorderLayout.CENTER);
        
		
	
	}
	

	public static void main(String[] arg) {
		JFrame_principal Display = new JFrame_principal();
		Display.setVisible(true);
		Display.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
		
	}
}
