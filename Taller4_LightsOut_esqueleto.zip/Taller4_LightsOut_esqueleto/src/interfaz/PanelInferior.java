package interfaz;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PanelInferior extends JPanel {
	public PanelInferior() {

	      this.setLayout(new BorderLayout());

	        JPanel labelContainer = new JPanel();
	        labelContainer.setLayout(new FlowLayout(FlowLayout.LEFT));

	        labelContainer.add(new JLabel("Jugadas: "));
	        labelContainer.add(new JLabel("0"));
	        labelContainer.add(new JLabel("Jugador: "));
	        labelContainer.add(new JLabel(""));

	        add(labelContainer, BorderLayout.NORTH);
	    }
	}

