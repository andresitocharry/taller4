package interfaz;

import javax.swing.*;
import java.awt.*;
import javax.swing.BoxLayout;

public class PanelDerecho extends JPanel {
    private JButton nuevoButton;
    private JButton reiniciarButton;
    private JButton top10Button;
    private JButton cambiarJugadorButton;

    public PanelDerecho() {
        
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        nuevoButton = createStyledButton("NUEVO");
        add(nuevoButton);
        
        add(Box.createVerticalStrut(10)); 

        reiniciarButton = createStyledButton("REINICIAR");
        add(reiniciarButton);

        add(Box.createVerticalStrut(10));

        top10Button = createStyledButton("TOP-10");
        add(top10Button);

        add(Box.createVerticalStrut(10));

        cambiarJugadorButton = createStyledButton("CAMBIAR JUGADOR");
        add(cambiarJugadorButton);
    }

    
    private JButton createStyledButton(String label) {
        JButton button = new JButton(label);
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(135, 206, 235));
        return button;
    }
}